package com.capgemini.serviceimpl;

public class CatalogServiceImpl {

}
