package com.capgemini.bean;

public class GiftCard {
	private String giftCardValue;
	private String giftCardId;

	public String getGiftCardId() {
		return giftCardId;
	}

	public void setGiftCardId(String giftCardId) {
		this.giftCardId = giftCardId;
	}

	public String getGiftCardValue() {
		return giftCardValue;
	}

	public void setGiftCardValue(String giftCardValue) {
		this.giftCardValue = giftCardValue;
	}

}
