DROP TABLE Product_Details;
CREATE TABLE Product_Details(
productId varchar(15) PRIMARY KEY,
productName varchar(15) NOT NULL,
productCost NUMBER NOT NULL
);

INSERT INTO Product_Details values('P00H1','Washing Machine',10000);
INSERT INTO Product_Details values('C00D1','Fridge',12000);
INSERT INTO Product_Details values('D00E1','Power Bank',2000);
INSERT INTO Product_Details values('F00V1','LCD',30000);
INSERT INTO Product_Details values('H00W1','Laptop',55000);