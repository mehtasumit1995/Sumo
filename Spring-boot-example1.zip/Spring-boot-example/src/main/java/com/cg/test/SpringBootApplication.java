package com.cg.test;

import org.springframework.boot.SpringApplication;

@org.springframework.boot.autoconfigure.SpringBootApplication
public class SpringBootApplication {
	public static void main(String[] args) throws Exception {
		SpringApplication.run(SpringBootApplication.class, args);
	}

}
